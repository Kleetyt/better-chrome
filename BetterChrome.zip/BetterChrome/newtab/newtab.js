// Update Clock
function updateClock() {
  const el = document.getElementById("clock");
  const now = new Date();
  el.textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}
setInterval(updateClock, 1000);
updateClock();

// Search bar
document.getElementById("search").addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    let q = e.target.value.trim();
    if (q.includes(".")) {
      window.location.href = "https://" + q;
    } else {
      window.location.href = "https://www.google.com/search?q=" + encodeURIComponent(q);
    }
  }
});

// Quick shortcuts
document.querySelectorAll(".shortcut").forEach(btn => {
  btn.onclick = () => window.location.href = btn.dataset.url;
});

// Settings page
document.getElementById("settings").onclick = () => {
  chrome.runtime.openOptionsPage();
};
