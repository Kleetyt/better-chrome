chrome.storage.sync.get("injectEnabled", ({ injectEnabled }) => {
  document.getElementById("toggleInject").checked = injectEnabled;
});

document.getElementById("toggleInject").addEventListener("change", (e) => {
  chrome.storage.sync.set({ injectEnabled: e.target.checked });
  chrome.runtime.sendMessage({ type: "toggleInject", enabled: e.target.checked });
});

document.getElementById("openOptions").onclick = () => {
  chrome.runtime.openOptionsPage();
};
