chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({
    injectEnabled: false
  });
});

// Listen to popup toggles & inject/remove CSS
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "toggleInject") {
    applyToAllTabs(msg.enabled);
  }
});

function applyToAllTabs(enabled) {
  chrome.tabs.query({}, (tabs) => {
    for (const tab of tabs) {
      if (!tab.id || !tab.url.startsWith("http")) continue;

      if (enabled) {
        chrome.scripting.insertCSS({
          target: { tabId: tab.id },
          files: ["inject.css"]
        });
      } else {
        chrome.scripting.removeCSS({
          target: { tabId: tab.id },
          files: ["inject.css"]
        });
      }
    }
  });
}
